# placeholder package used only by the Terraform plan tests
